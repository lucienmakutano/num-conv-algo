# num-conv-algo
implements number conversion algorithms
