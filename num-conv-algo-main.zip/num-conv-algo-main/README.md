# num-conv-algo
//implements number conversion algorithms (Whole number conversions)

//Divide the number by 2 through % and store the remainder in an array
//Divide the number by 2 through /
//Repeat step 2 until number is greater than zero

#include <iostream>  

using namespace std;  

int main()  

{  
int array[10]; 
int number;
int i; 

cout<<"Enter the number to convert: ";   

cin>>number;    

for(i=0; number>0; i++)    

{    

array[i]=number%2;    

number= number/2;  

}    

cout<<"Binary equivalent = ";  

for(i=i-1 ;i>=0 ;i--)    

{    

cout<<array[i];    

}    
}

